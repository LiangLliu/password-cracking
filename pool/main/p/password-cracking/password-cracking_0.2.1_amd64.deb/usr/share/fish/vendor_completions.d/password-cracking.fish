# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_password_cracking_global_optspecs
    string join \n f/file= t/threads= q/quiet checkpoint= resume checkpoint-interval= pdf-owner h/help V/version
end

function __fish_password_cracking_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_password_cracking_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_password_cracking_using_subcommand
    set -l cmd (__fish_password_cracking_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c password-cracking -n "__fish_password_cracking_needs_command" -s f -l file -d 'Target file to crack (not needed for completions/man)' -r -F
complete -c password-cracking -n "__fish_password_cracking_needs_command" -s t -l threads -d 'Number of threads (default: all logical cores)' -r
complete -c password-cracking -n "__fish_password_cracking_needs_command" -l checkpoint -d 'Save progress to this file periodically, allowing --resume' -r -F
complete -c password-cracking -n "__fish_password_cracking_needs_command" -l checkpoint-interval -d 'Seconds between checkpoint writes (default: 5)' -r
complete -c password-cracking -n "__fish_password_cracking_needs_command" -s q -l quiet -d 'Quiet mode: only show the result'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -l resume -d 'Resume from the file given by --checkpoint'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -l pdf-owner -d 'Also try PDF owner passwords (slower: ~3x verification cost)'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -s V -l version -d 'Print version'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -f -a "dictionary" -d 'Dictionary attack using a wordlist file or directory'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -f -a "brute-force" -d 'Brute-force attack over a character set'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -f -a "mask" -d 'Mask attack: per-position character sets (e.g. ?u?l?l?l?d?d)'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -f -a "hybrid" -d 'Hybrid attack: dictionary words + mutation rules'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -f -a "completions" -d 'Generate shell completion scripts for the given shell'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -f -a "man" -d 'Generate a roff man page on stdout'
complete -c password-cracking -n "__fish_password_cracking_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -s w -l wordlist -d 'Path to wordlist file or directory of .txt files' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -s t -l threads -d 'Number of threads (default: all logical cores)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -l checkpoint -d 'Save progress to this file periodically, allowing --resume' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -l checkpoint-interval -d 'Seconds between checkpoint writes (default: 5)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -l dedup -d 'Remove duplicate candidates (uses memory proportional to uniques)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -s q -l quiet -d 'Quiet mode: only show the result'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -l resume -d 'Resume from the file given by --checkpoint'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -l pdf-owner -d 'Also try PDF owner passwords (slower: ~3x verification cost)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand dictionary" -s h -l help -d 'Print help'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -s c -l charset -d 'Character set: digits, lower, upper, special, alnum, all, or custom string' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -l min-length -d 'Minimum password length' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -l max-length -d 'Maximum password length' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -s t -l threads -d 'Number of threads (default: all logical cores)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -l checkpoint -d 'Save progress to this file periodically, allowing --resume' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -l checkpoint-interval -d 'Seconds between checkpoint writes (default: 5)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -s q -l quiet -d 'Quiet mode: only show the result'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -l resume -d 'Resume from the file given by --checkpoint'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -l pdf-owner -d 'Also try PDF owner passwords (slower: ~3x verification cost)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand brute-force" -s h -l help -d 'Print help'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -s m -l mask -d 'Mask pattern (?d digits, ?l lower, ?u upper, ?s special, ?a all, ?? literal ?)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -s t -l threads -d 'Number of threads (default: all logical cores)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -l checkpoint -d 'Save progress to this file periodically, allowing --resume' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -l checkpoint-interval -d 'Seconds between checkpoint writes (default: 5)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -s q -l quiet -d 'Quiet mode: only show the result'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -l resume -d 'Resume from the file given by --checkpoint'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -l pdf-owner -d 'Also try PDF owner passwords (slower: ~3x verification cost)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand mask" -s h -l help -d 'Print help'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -s w -l wordlist -d 'Path to wordlist' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l append-digits -d 'Append 0..=N to each word' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -s t -l threads -d 'Number of threads (default: all logical cores)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l checkpoint -d 'Save progress to this file periodically, allowing --resume' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l checkpoint-interval -d 'Seconds between checkpoint writes (default: 5)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l capitalize -d 'Capitalize first letter'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l upper -d 'Convert to uppercase'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l lower -d 'Convert to lowercase'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l l33t -d 'Apply l33t-speak substitutions (a→@, e→3, i→1, o→0, s→$)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l reverse -d 'Reverse the word'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l duplicate -d 'Duplicate the word (e.g. pass→passpass)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -s q -l quiet -d 'Quiet mode: only show the result'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l resume -d 'Resume from the file given by --checkpoint'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -l pdf-owner -d 'Also try PDF owner passwords (slower: ~3x verification cost)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand hybrid" -s h -l help -d 'Print help'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand completions" -s t -l threads -d 'Number of threads (default: all logical cores)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand completions" -l checkpoint -d 'Save progress to this file periodically, allowing --resume' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand completions" -l checkpoint-interval -d 'Seconds between checkpoint writes (default: 5)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand completions" -s q -l quiet -d 'Quiet mode: only show the result'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand completions" -l resume -d 'Resume from the file given by --checkpoint'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand completions" -l pdf-owner -d 'Also try PDF owner passwords (slower: ~3x verification cost)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand completions" -s h -l help -d 'Print help'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand man" -s t -l threads -d 'Number of threads (default: all logical cores)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand man" -l checkpoint -d 'Save progress to this file periodically, allowing --resume' -r -F
complete -c password-cracking -n "__fish_password_cracking_using_subcommand man" -l checkpoint-interval -d 'Seconds between checkpoint writes (default: 5)' -r
complete -c password-cracking -n "__fish_password_cracking_using_subcommand man" -s q -l quiet -d 'Quiet mode: only show the result'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand man" -l resume -d 'Resume from the file given by --checkpoint'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand man" -l pdf-owner -d 'Also try PDF owner passwords (slower: ~3x verification cost)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand man" -s h -l help -d 'Print help'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand help; and not __fish_seen_subcommand_from dictionary brute-force mask hybrid completions man help" -f -a "dictionary" -d 'Dictionary attack using a wordlist file or directory'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand help; and not __fish_seen_subcommand_from dictionary brute-force mask hybrid completions man help" -f -a "brute-force" -d 'Brute-force attack over a character set'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand help; and not __fish_seen_subcommand_from dictionary brute-force mask hybrid completions man help" -f -a "mask" -d 'Mask attack: per-position character sets (e.g. ?u?l?l?l?d?d)'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand help; and not __fish_seen_subcommand_from dictionary brute-force mask hybrid completions man help" -f -a "hybrid" -d 'Hybrid attack: dictionary words + mutation rules'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand help; and not __fish_seen_subcommand_from dictionary brute-force mask hybrid completions man help" -f -a "completions" -d 'Generate shell completion scripts for the given shell'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand help; and not __fish_seen_subcommand_from dictionary brute-force mask hybrid completions man help" -f -a "man" -d 'Generate a roff man page on stdout'
complete -c password-cracking -n "__fish_password_cracking_using_subcommand help; and not __fish_seen_subcommand_from dictionary brute-force mask hybrid completions man help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
